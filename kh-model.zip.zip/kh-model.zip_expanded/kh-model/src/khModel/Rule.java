package khModel;

public enum Rule {
	ATTRACTIVE,SIMILAR,MIXED,FRUSTRATION
}
